/**
 * FitLife Pro - Main Application Logic (Phase 3)
 * Full Feature Set: Auth, AI, Nutrition, Social, Vision, Persistence
 */

// --- STORE (Data Layer) ---
const Store = {
    state: {
        isAuthenticated: false,
        apiKey: '', // For real AI features
        user: {
            name: '',
            email: '',
            goal: 'build_muscle',
            stats: { calories: 1240, workoutTime: 45, streak: 12, weight: 75.5 }
        },
        nutrition: {
            today: { protein: 110, carbs: 180, fats: 45, water: 4, calories: 1240 },
            targets: { protein: 180, carbs: 250, fats: 70, water: 8, calories: 2400 },
            logs: []
        },
        workouts: [
            { id: 1, title: 'HIIT Blast', type: 'Cardio', duration: '20 min', intensity: 'High', icon: 'flame', color: '#fca5a5' },
            { id: 2, title: 'Strength Alpha', type: 'Strength', duration: '60 min', intensity: 'High', icon: 'dumbbell', color: '#93c5fd' },
            { id: 3, title: 'Yoga Flow', type: 'Flexibility', duration: '45 min', intensity: 'Low', icon: 'waves', color: '#86efac' }
        ],
        challenges: [
            { title: 'Early Bird', desc: 'Workout before 8AM', progress: 3, target: 5, icon: 'sun' },
            { title: 'Hydration King', desc: 'Drink 3L water', progress: 21, target: 30, icon: 'droplet' }
        ]
    },

    init() {
        const saved = localStorage.getItem('fitlife_state');
        if (saved) {
            this.state = JSON.parse(saved);
        }
    },

    save() {
        localStorage.setItem('fitlife_state', JSON.stringify(this.state));
    },

    login(email, password) {
        this.state.isAuthenticated = true;
        this.state.user.email = email;
        this.state.user.name = email.split('@')[0];
        this.save();
        Router.navigate('dashboard');
    },

    signup(name, email, password, goal) {
        this.state.isAuthenticated = true;
        this.state.user.name = name;
        this.state.user.email = email;
        this.state.user.goal = goal;
        this.save();
        Router.navigate('dashboard');
    },

    logout() {
        this.state.isAuthenticated = false;
        this.save();
        Router.navigate('login');
    },

    updateSettings(name, goal, apiKey) {
        this.state.user.name = name;
        this.state.user.goal = goal;
        this.state.apiKey = apiKey;
        this.save();
        alert('Settings Saved!');
    },

    addNutritionLog(item, calories, protein, carbs, fats) {
        this.state.nutrition.logs.unshift({ item, calories, time: new Date().toLocaleTimeString() });
        this.state.nutrition.today.calories += calories;
        this.state.nutrition.today.protein += protein;
        this.state.nutrition.today.carbs += carbs;
        this.state.nutrition.today.fats += fats;
        this.save();
    },

    generatePlan(goal, equip, time) {
        const newPlan = {
            id: Date.now(),
            title: `AI: ${goal.replace('_', ' ')}`,
            type: 'Custom',
            duration: `${time} min`,
            intensity: 'Adaptive',
            icon: 'bot',
            color: '#c084fc'
        };
        this.state.workouts.unshift(newPlan);
        this.save();
        return newPlan;
    }
};

// --- VISION SERVICE ---
const VisionService = {
    async analyzeImage(file) {
        // Mock fallback if no API key
        if (!Store.state.apiKey) {
            return new Promise((resolve) => {
                setTimeout(() => {
                    const mockFoods = [
                        { item: 'Avocado Toast', calories: 350, p: 12, c: 45, f: 18 },
                        { item: 'Grilled Chicken Salad', calories: 420, p: 45, c: 12, f: 20 },
                        { item: 'Protein Smoothie', calories: 280, p: 30, c: 25, f: 5 },
                        { item: 'Oatmeal & Berries', calories: 310, p: 10, c: 55, f: 6 }
                    ];
                    const result = mockFoods[Math.floor(Math.random() * mockFoods.length)];
                    resolve(result);
                }, 1500);
            });
        }

        // Real API Call
        try {
            const base64 = await this.fileToBase64(file);
            const response = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${Store.state.apiKey}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [
                        {
                            role: "user",
                            content: [
                                { type: "text", text: "Identify the food in this image and estimate the calories and macros. JSON only: { item: string, calories: number, p: number, c: number, f: number }." },
                                { type: "image_url", image_url: { url: base64 } }
                            ]
                        }
                    ],
                    max_tokens: 300
                })
            });

            const data = await response.json();
            const content = data.choices[0].message.content;
            // Extract JSON from potential markdown blocks
            const jsonStr = content.replace(/```json|```/g, '').trim();
            return JSON.parse(jsonStr);

        } catch (error) {
            console.error(error);
            alert('API Error. Falling back to simulation.');
            return { item: 'Unknown Food', calories: 250, p: 0, c: 0, f: 0 };
        }
    },

    fileToBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve(reader.result);
            reader.onerror = error => reject(error);
        });
    }
};

// --- ROUTER ---
const Router = {
    routes: {
        'login': () => LoginView(),
        'signup': () => SignupView(),
        'dashboard': () => DashboardView(),
        'workouts': () => WorkoutsView(),
        'generator': () => GeneratorView(),
        'nutrition': () => NutritionView(),
        'settings': () => SettingsView()
    },

    init() {
        Store.init();
        window.addEventListener('hashchange', () => this.render());
        this.render();
    },

    navigate(os) {
        window.location.hash = os;
    },

    render() {
        const hash = window.location.hash.slice(1) || 'login';
        const root = document.getElementById('root');

        if (!Store.state.isAuthenticated && hash !== 'login' && hash !== 'signup') {
            this.navigate('login');
            return;
        }

        if (hash === 'login' || hash === 'signup') {
            root.innerHTML = this.routes[hash]();
        } else {
            root.innerHTML = AppLayout(this.routes[hash] ? this.routes[hash]() : DashboardView());
            this.updateActiveNav(hash);
        }
        lucide.createIcons();
    },

    updateActiveNav(hash) {
        document.querySelectorAll('.nav-link, .mobile-nav-item').forEach(el => {
            el.classList.remove('active');
            if (el.getAttribute('href') === `#${hash}`) el.classList.add('active');
        });
    }
};

// --- LAYOUTS ---
const AppLayout = (content) => `
    <div class="app-layout">
        <nav class="sidebar">
            <div style="font-family: 'Outfit'; font-weight: 800; font-size: 1.5rem; display: flex; align-items: center; gap: 0.5rem; color: #fff; margin-bottom: 2rem;">
                <i data-lucide="dumbbell" style="color: var(--primary);"></i>
                FITLIFE<span style="color: var(--primary);">PRO</span>
            </div>
            ${NavLinks()}
            <div style="margin-top:auto">
                <button onclick="Store.logout()" class="nav-link btn-ghost" style="width:100%; color:#ef4444;">
                    <i data-lucide="log-out"></i> Logout
                </button>
            </div>
        </nav>

        <main class="main-content">
            <header style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                <div>
                     <h1>Hello, <span class="text-accent">${Store.state.user.name}</span></h1>
                     <p class="text-muted">Let's crush today's goals.</p>
                </div>
                <div style="width: 40px; height: 40px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #000; font-weight: bold;">
                    ${Store.state.user.name.charAt(0).toUpperCase()}
                </div>
            </header>
            ${content}
        </main>

        <nav class="mobile-nav">
            <a href="#dashboard" class="mobile-nav-item"><i data-lucide="home"></i>Home</a>
            <a href="#workouts" class="mobile-nav-item"><i data-lucide="dumbbell"></i>Work</a>
            <a href="#generator" class="mobile-nav-item"><i data-lucide="bot"></i>AI</a>
            <a href="#nutrition" class="mobile-nav-item"><i data-lucide="apple"></i>Food</a>
            <a href="#settings" class="mobile-nav-item"><i data-lucide="user"></i>Me</a>
        </nav>
    </div>
`;

const NavLinks = () => `
    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
        <a href="#dashboard" class="nav-link"><i data-lucide="layout-dashboard"></i>Dashboard</a>
        <a href="#workouts" class="nav-link"><i data-lucide="dumbbell"></i>Workouts</a>
        <a href="#generator" class="nav-link"><i data-lucide="bot"></i>AI Generator</a>
        <a href="#nutrition" class="nav-link"><i data-lucide="apple"></i>Nutrition</a>
        <a href="#settings" class="nav-link"><i data-lucide="settings"></i>Settings</a>
    </div>
`;

// --- VIEWS ---

const LoginView = () => `
    <div class="auth-container">
        <div class="auth-card">
            <div style="text-align: center; margin-bottom: 2rem;">
                <i data-lucide="dumbbell" style="width: 48px; height: 48px; color: var(--primary); margin-bottom: 1rem;"></i>
                <h2>Welcome Back</h2>
                <p class="text-muted">Login to access your personalized fitness plan.</p>
            </div>
            <form onsubmit="event.preventDefault(); Store.login(this.email.value, this.password.value)">
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-input" placeholder="you@example.com" value="user@fitlife.pro" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-input" placeholder="••••••••" value="password" required>
                </div>
                <button type="submit" class="btn">Login Account</button>
            </form>
            <p style="text-align: center; margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
                New here? <a href="#signup" style="color: var(--primary);">Create Account</a>
            </p>
        </div>
    </div>
`;

const SignupView = () => `
    <div class="auth-container">
        <div class="auth-card">
            <div style="text-align: center; margin-bottom: 2rem;">
                <h2>Create Account</h2>
                <p class="text-muted">Start your transformation today.</p>
            </div>
            <form onsubmit="event.preventDefault(); Store.signup(this.name.value, this.email.value, this.password.value, this.goal.value)">
                <div class="form-group">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="name" class="form-input" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-input" placeholder="••••••••" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Primary Goal</label>
                    <select name="goal" class="form-input">
                        <option value="lose_weight">Lose Weight</option>
                        <option value="build_muscle">Build Muscle</option>
                        <option value="improve_endurance">Endurance</option>
                    </select>
                </div>
                <button type="submit" class="btn">Sign Up</button>
            </form>
            <p style="text-align: center; margin-top: 1.5rem; font-size: 0.9rem; color: var(--text-muted);">
                Already have an account? <a href="#login" style="color: var(--primary);">Login</a>
            </p>
        </div>
    </div>
`;

const DashboardView = () => `
    <div class="animate-enter">
        <div class="stats-scroller">
            <div class="grid-4">
                ${StatCard('Calories', Store.state.nutrition.today.calories, 'flame', 'kcal')}
                ${StatCard('Workout Time', Store.state.user.stats.workoutTime, 'timer', 'min')}
                ${StatCard('Streak', Store.state.user.stats.streak, 'zap', 'days')}
                ${StatCard('Weight', Store.state.user.stats.weight, 'scale', 'kg')}
            </div>
        </div>

        <div class="grid-2" style="margin-top: 2rem;">
            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h3>Today's Focus</h3>
                    <span style="font-size: 0.8rem; background: var(--primary); color: #000; padding: 2px 8px; border-radius: 4px;">RECOMMENDED</span>
                </div>
                <div style="background: rgba(255,255,255,0.03); border-radius: 12px; padding: 1rem; display: flex; gap: 1rem; align-items: center;">
                    <div style="width: 60px; height: 60px; background: #3b82f6; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                        <i data-lucide="dumbbell" style="color:#fff"></i>
                    </div>
                    <div>
                        <h4>Upper Body Power</h4>
                        <p class="text-muted">45 min • Intermediate</p>
                    </div>
                </div>
                <button class="btn" style="margin-top: 1rem;" onclick="alert('Workout Started!')">Start Workout</button>
            </div>

            <div class="card">
                <h3>Active Challenges</h3>
                 <div style="margin-top: 1rem; display: flex; flex-direction: column; gap: 1rem;">
                    ${Store.state.challenges.map(c => `
                        <div>
                            <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 0.25rem;">
                                <span>${c.title}</span>
                                <span class="text-accent">${c.progress}/${c.target}</span>
                            </div>
                            <div style="height: 6px; background: #27272a; border-radius: 10px; overflow: hidden;">
                                <div style="width: ${(c.progress / c.target) * 100}%; height: 100%; background: var(--primary);"></div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    </div>
`;

const WorkoutsView = () => `
    <div class="animate-enter">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
            <h2>Workout Library</h2>
            <button onclick="Router.navigate('generator')" class="btn-secondary" style="padding: 0.5rem 1rem; border-radius: 8px;">
                <i data-lucide="bot" style="width: 16px;"></i> AI Gen
            </button>
        </div>
        <div class="grid-3">
            ${Store.state.workouts.map(w => `
                <div class="card">
                    <div style="height: 100px; background: ${w.color}22; border-radius: 12px; margin-bottom: 1rem; display: flex; align-items: center; justify-content: center;">
                        <i data-lucide="${w.icon}" style="color: ${w.color}; width: 32px; height: 32px;"></i>
                    </div>
                    <h4>${w.title}</h4>
                    <p class="text-muted" style="font-size: 0.9rem;">${w.type} • ${w.intensity}</p>
                    <div style="margin-top: 1rem; display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 0.8rem; background: #27272a; padding: 4px 8px; border-radius: 4px;">${w.duration}</span>
                        <button class="btn-ghost" style="padding: 4px;" onclick="alert('Starting ${w.title}...')">Start</button>
                    </div>
                </div>
            `).join('')}
        </div>
    </div>
`;

const GeneratorView = () => `
    <div class="animate-enter">
        <div style="max-width: 600px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #a855f7, #ec4899); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 1rem; box-shadow: 0 0 20px rgba(168, 85, 247, 0.4);">
                    <i data-lucide="bot" style="color: white; width: 32px; height: 32px;"></i>
                </div>
                <h2>AI Workout Generator</h2>
                <p class="text-muted">Tell us what you have, we'll build the plan.</p>
            </div>

            <div class="card">
                <form onsubmit="handleGenerate(event)">
                    <div class="form-group">
                        <label class="form-label">Fitness Goal</label>
                        <select id="gen-goal" class="form-input">
                            <option value="lose_weight">Lose Weight</option>
                            <option value="build_muscle">Build Muscle</option>
                            <option value="improve_endurance">Improve Endurance</option>
                        </select>
                    </div>
                    <div class="grid-2">
                        <div class="form-group">
                            <label class="form-label">Equipment</label>
                            <select id="gen-equip" class="form-input">
                                <option value="gym">Full Gym</option>
                                <option value="dumbbells">Dumbbells Only</option>
                                <option value="bodyweight">Bodyweight</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Duration (min)</label>
                            <input id="gen-time" type="number" class="form-input" value="45">
                        </div>
                    </div>
                    <button type="submit" class="btn" style="background: linear-gradient(to right, #a855f7, #ec4899); color: white;">
                        <i data-lucide="sparkles"></i> Generate Plan
                    </button>
                </form>
            </div>
        </div>
    </div>
`;

const NutritionView = () => `
    <div class="animate-enter">
        <h2>Nutrition Tracker</h2>
        
        <!-- AI Camera Section -->
        <div class="card" style="margin-top: 1.5rem; border: 2px dashed #3f3f46; position: relative; overflow: hidden;">
            <div id="camera-scan-area" style="text-align: center; padding: 2rem;">
                <i data-lucide="camera" style="width: 48px; height: 48px; color: var(--primary); margin-bottom: 1rem;"></i>
                <h3>Snap Meal & Track</h3>
                <p class="text-muted" style="margin-bottom: 1.5rem;">Use AI to analyze your food automatically.</p>
                <button onclick="document.getElementById('file-input').click()" class="btn" style="max-width: 200px;">
                    Take Photo / Upload
                </button>
                <input type="file" id="file-input" accept="image/*" style="display: none;" onchange="handleScan(this)">
            </div>
            
            <!-- Analysis Result Overlay (Hidden by default) -->
            <div id="scan-result" style="display: none; padding: 2rem; background: rgba(0,0,0,0.8); position: absolute; top:0; left:0; right:0; bottom:0; align-items: center; justify-content: center; flex-direction: column;">
                 <i data-lucide="loader-2" class="spin" style="width: 48px; height: 48px; color: var(--primary);"></i>
                 <p style="margin-top: 1rem;">AI Analyzing...</p>
            </div>
        </div>

        <div class="grid-2" style="margin-top: 1.5rem;">
            <!-- Calories Main -->
            <div class="card" style="text-align: center; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <div style="width: 150px; height: 150px; border-radius: 50%; border: 8px solid #27272a; border-top-color: var(--primary); border-right-color: var(--primary); display: flex; flex-direction: column; align-items: center; justify-content: center; margin-bottom: 1rem;">
                    <span style="font-size: 2rem; font-weight: 800;">${Store.state.nutrition.today.calories}</span>
                    <span class="text-muted" style="font-size: 0.8rem;"> / ${Store.state.nutrition.targets.calories} kcal</span>
                </div>
            </div>

            <!-- Macros -->
            <div class="card">
                <h3>Macros</h3>
                <div style="display: flex; flex-direction: column; gap: 1.5rem; margin-top: 1rem;">
                    ${MacroBar('Protein', Store.state.nutrition.today.protein, Store.state.nutrition.targets.protein, '#3b82f6')}
                    ${MacroBar('Carbs', Store.state.nutrition.today.carbs, Store.state.nutrition.targets.carbs, '#ec4899')}
                    ${MacroBar('Fats', Store.state.nutrition.today.fats, Store.state.nutrition.targets.fats, '#eab308')}
                </div>
            </div>
        </div>

        <!-- Recent Logs -->
        <div style="margin-top: 2rem;">
            <h3>Recent Logs</h3>
            <div style="display: flex; flex-direction: column; gap: 0.5rem; margin-top: 1rem;">
                ${Store.state.nutrition.logs.length === 0 ? '<p class="text-muted">No food logged yet.</p>' : ''}
                ${Store.state.nutrition.logs.map(log => `
                    <div class="card" style="padding: 1rem; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4>${log.item}</h4>
                            <p class="text-muted" style="font-size: 0.8rem;">${log.time}</p>
                        </div>
                        <span style="color: var(--primary); font-weight: bold;">+${log.calories} kcal</span>
                    </div>
                `).join('')}
            </div>
        </div>
    </div>
`;

const SettingsView = () => `
    <div class="animate-enter">
        <h2>Settings</h2>
        <div class="card" style="margin-top: 1.5rem;">
            <form onsubmit="event.preventDefault(); Store.updateSettings(this.name.value, this.goal.value, this.apikey.value)">
                <div class="form-group">
                    <label class="form-label">Display Name</label>
                    <input type="text" name="name" class="form-input" value="${Store.state.user.name}">
                </div>
                <div class="form-group">
                     <label class="form-label">Fitness Goal</label>
                    <select name="goal" class="form-input" value="${Store.state.user.goal}">
                        <option value="lose_weight">Lose Weight</option>
                        <option value="build_muscle">Build Muscle</option>
                        <option value="improve_endurance">Endurance</option>
                    </select>
                </div>
                
                <hr style="border-color: #333; margin: 2rem 0;">
                
                <h3>Integration</h3>
                <p class="text-muted" style="margin-bottom: 1rem; font-size: 0.9rem;">
                    Add your OpenAI API Key to enable REAL AI analysis for the Food Scanner. 
                    Leave blank to use the simulator.
                </p>
                <div class="form-group">
                    <label class="form-label">OpenAI API Key</label>
                    <input type="password" name="apikey" class="form-input" placeholder="sk-..." value="${Store.state.apiKey || ''}">
                </div>

                <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn">Save Changes</button>
                    <button type="button" class="btn-secondary" style="width: auto; padding: 0 1.5rem;" onclick="location.reload()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
`;

// --- HELPERS ---
const StatCard = (label, value, icon, unit = '') => `
    <div class="card" style="padding: 1.25rem;">
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
            <p class="stat-label">${label}</p>
            <i data-lucide="${icon}" style="width: 18px; color: var(--text-muted);"></i>
        </div>
        <h3 class="stat-value" style="font-size: 1.5rem;">${value}<span style="font-size: 0.9rem; color: var(--text-muted); font-weight: 500;">${unit}</span></h3>
    </div>
`;

const MacroBar = (label, val, target, color) => `
    <div>
        <div style="display: flex; justify-content: space-between; font-size: 0.9rem; margin-bottom: 0.25rem;">
            <span>${label}</span>
            <span style="color: ${color};">${val}g</span>
        </div>
        <div style="height: 6px; background: #27272a; border-radius: 10px; overflow: hidden;">
            <div style="width: ${(val / target) * 100}%; height: 100%; background: ${color};"></div>
        </div>
    </div>
`;

// Actions
window.handleGenerate = (e) => {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    btn.innerHTML = `<i data-lucide="loader-2" class="spin"></i> Generating...`;

    setTimeout(() => {
        const goal = document.getElementById('gen-goal').value;
        const equip = document.getElementById('gen-equip').value;
        const time = document.getElementById('gen-time').value;

        Store.generatePlan(goal, equip, time);
        Router.navigate('workouts');
        alert('Plan Generated Successfully!');
    }, 1500);
};

window.handleScan = async (input) => {
    if (input.files && input.files[0]) {
        const file = input.files[0];

        // Show Overlay
        const overlay = document.getElementById('scan-result');
        overlay.style.display = 'flex';

        // Analyze
        const result = await VisionService.analyzeImage(file);

        // Update State
        Store.addNutritionLog(result.item, result.calories, result.p, result.c, result.f);

        // Refresh UI
        Router.render();
        alert(`Analysis Complete: ${result.item} (${result.calories} kcal) added!`);
    }
};

// Styles
const style = document.createElement('style');
style.innerHTML = `
@keyframes spin { 100% { transform: rotate(360deg); } }
.spin { animation: spin 1s linear infinite; }
`;
document.head.appendChild(style);

// Init
Router.init();
