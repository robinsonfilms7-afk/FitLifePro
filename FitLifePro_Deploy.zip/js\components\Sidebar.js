export default function Sidebar() {
    return `
        <div style="padding-bottom: 2rem; border-bottom: 1px solid #27272a; margin-bottom: 1rem;">
            <div style="font-family: 'Outfit'; font-weight: 800; font-size: 1.5rem; display: flex; align-items: center; gap: 0.5rem; color: #fff;">
                <i data-lucide="dumbbell" style="color: var(--primary);"></i>
                FITLIFE<span style="color: var(--primary);">PRO</span>
            </div>
        </div>
        
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <a href="#dashboard" class="nav-link">
                <i data-lucide="layout-dashboard"></i>
                <span>Dashboard</span>
            </a>
            <a href="#workouts" class="nav-link">
                <i data-lucide="biceps-flexed"></i>
                <span>Workouts</span>
            </a>
            <a href="#progress" class="nav-link">
                <i data-lucide="trending-up"></i>
                <span>Progress</span>
            </a>
            <a href="#settings" class="nav-link">
                <i data-lucide="settings"></i>
                <span>Settings</span>
            </a>
        </div>
        
        <div style="margin-top: auto;">
            <div class="card" style="background: linear-gradient(145deg, #1f2937, #111827); padding: 1rem;">
                <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.5rem;">Weekly Goal</p>
                <div style="height: 6px; background: #374151; border-radius: 10px; overflow: hidden;">
                    <div style="width: 75%; height: 100%; background: var(--primary);"></div>
                </div>
                <p style="font-size: 0.75rem; margin-top: 0.5rem; text-align: right;">3/4 Workouts</p>
            </div>
        </div>
    `;
}
