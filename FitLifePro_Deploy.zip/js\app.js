import Sidebar from './components/Sidebar.js';
import Dashboard from './pages/Dashboard.js';
import Workouts from './pages/Workouts.js';
import Progress from './pages/Progress.js';

// Simple Router
const routes = {
    'dashboard': Dashboard,
    'workouts': Workouts,
    'progress': Progress
};

function render() {
    // Render Sidebar (once)
    const sidebarEl = document.getElementById('sidebar');
    if (sidebarEl.innerHTML.trim() === '') {
        sidebarEl.innerHTML = Sidebar();
        lucide.createIcons(); // Re-scan for icons
    }

    // Handle Page Content
    const hash = window.location.hash.slice(1) || 'dashboard';
    const pageContainer = document.getElementById('page-container');

    // Clear current content
    pageContainer.innerHTML = '';

    const PageComponent = routes[hash] || Dashboard;
    pageContainer.innerHTML = PageComponent();

    // Update Active Nav State
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${hash}`) {
            link.classList.add('active');
        }
    });

    // Re-initialize icons for new content
    lucide.createIcons();
}

// Global Event Handler
window.addEventListener('start-workout', (e) => {
    import('./components/ActiveSession.js').then(module => {
        const ActiveSession = module.default;
        const overlay = document.createElement('div');
        overlay.innerHTML = ActiveSession(e.detail.title);
        document.body.appendChild(overlay);

        // Start Timer
        let seconds = 0;
        const timerEl = document.getElementById('session-timer');
        const interval = setInterval(() => {
            seconds++;
            const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
            const secs = (seconds % 60).toString().padStart(2, '0');
            if (timerEl) timerEl.innerText = `${mins}:${secs}`;
            else clearInterval(interval); // Stop if element removed
        }, 1000);
    });
});

// Event Listeners
window.addEventListener('hashchange', render);
window.addEventListener('DOMContentLoaded', render);
