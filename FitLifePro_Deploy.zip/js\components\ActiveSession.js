export default function ActiveSession(workoutTitle) {
    return `
        <div id="active-session-overlay" style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: #000; z-index: 1000; animation: fade-in-up 0.3s var(--ease-out); display: flex; flex-direction: column;">
            
            <!-- Header -->
            <header style="padding: 1.5rem; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #333;">
                <div>
                    <p style="color: var(--text-muted); font-size: 0.9rem;">Current Session</p>
                    <h2>${workoutTitle}</h2>
                </div>
                <div style="text-align: right;">
                    <p style="font-family: 'Outfit'; font-size: 2rem; font-weight: 700; color: var(--primary);" id="session-timer">00:00</p>
                </div>
            </header>

            <!-- Main Content -->
            <div style="flex: 1; padding: 2rem; overflow-y: auto;">
                <div style="max-width: 800px; margin: 0 auto; display: flex; flex-direction: column; gap: 1.5rem;">
                    
                    ${ExerciseItem('Warm Up: Jumping Jacks', '2 mins', false)}
                    ${ExerciseItem('Push Ups', '3 x 12 reps', true)}
                    ${ExerciseItem('Dumbbell Rows', '3 x 12 reps', true)}
                    ${ExerciseItem('Shoulder Press', '3 x 10 reps', true)}
                    ${ExerciseItem('Plank', '3 x 60 sec', true)}

                </div>
            </div>

            <!-- Footer Controls -->
            <div style="padding: 1.5rem; border-top: 1px solid #333; background: #09090b; display: flex; gap: 1rem; justify-content: flex-end;">
                 <button onclick="document.getElementById('active-session-overlay').remove()" class="btn-ghost" style="color: #ef4444;">Cancel Workout</button>
                 <button onclick="alert('Workout Saved!'); document.getElementById('active-session-overlay').remove()" class="btn">Complete Session</button>
            </div>
        </div>
        <script>
            // Simple Timer Logic (This would ideally be in the main app closure, injecting here for simplicity of the string template)
            // In a real app, this script tag won't execute when injected via innerHTML. 
            // We'll handle the timer in the app.js event listener.
        </script>
    `;
}

function ExerciseItem(name, details, hasInput) {
    return `
    <div style="background: #18181b; padding: 1.5rem; border-radius: 16px; display: flex; align-items: center; justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 1rem;">
            <div style="width: 24px; height: 24px; border: 2px solid #52525b; border-radius: 50%;"></div>
            <div>
                <h4 style="font-size: 1.1rem; margin-bottom: 0.2rem;">${name}</h4>
                <p style="color: var(--text-muted); font-size: 0.9rem;">${details}</p>
            </div>
        </div>
        ${hasInput ?
            `<div style="display: flex; gap: 0.5rem; align-items: center;">
                <input type="number" placeholder="kg" style="background: #27272a; border: none; color: #fff; padding: 0.5rem; border-radius: 8px; width: 60px; text-align: center;">
                <span style="color: var(--text-muted);">x</span>
                <input type="number" placeholder="reps" style="background: #27272a; border: none; color: #fff; padding: 0.5rem; border-radius: 8px; width: 60px; text-align: center;">
            </div>`
            : ''}
    </div>
    `
}
