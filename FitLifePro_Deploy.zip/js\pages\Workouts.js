export default function Workouts() {
    return `
        <div class="animate-enter">
            <h2 style="margin-bottom: 1.5rem;">Workout Library</h2>
            
            <div class="grid-3">
                ${WorkoutCard('HIIT Blast', '20 min • High Intensity', 'flame', '#fca5a5')}
                ${WorkoutCard('Strength Alpha', '60 min • Heavy Weighs', 'dumbbell', '#93c5fd')}
                ${WorkoutCard('Yoga Flow', '45 min • Recovery', 'waves', '#86efac')}
                ${WorkoutCard('Core Crusher', '15 min • Abs Focus', 'target', '#c4b5fd')}
                ${WorkoutCard('Marathon Prep', '90 min • Endurance', 'timer', '#fdba74')}
                ${WorkoutCard('Full Body', '40 min • Equipment Free', 'user', '#fcd34d')}
            </div>
        </div>
    `;
}

function WorkoutCard(title, subtitle, icon, color) {
    return `
    <div class="card" style="cursor: pointer;">
        <div style="height: 120px; background: linear-gradient(135deg, ${color}22, ${color}44); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 1rem;">
            <i data-lucide="${icon}" style="width: 48px; height: 48px; color: ${color};"></i>
        </div>
        <h3 style="font-size: 1.25rem; margin-bottom: 0.25rem;">${title}</h3>
        <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">${subtitle}</p>
        <button onclick="window.dispatchEvent(new CustomEvent('start-workout', { detail: { title: '${title}' } }))" class="btn-ghost" style="padding-left: 0; color: ${color};">Start Now →</button>
    </div>
    `
}
