export default function Dashboard() {
    return `
        <div class="animate-enter">
            <!-- Stats Grid -->
            <div class="grid-4" style="margin-bottom: 2rem;">
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p class="stat-label">Active Calories</p>
                            <h3 class="stat-value">840</h3>
                            <p style="color: #4ade80; font-size: 0.85rem;">+12% vs last week</p>
                        </div>
                        <i data-lucide="flame" style="color: var(--accent-orange);"></i>
                    </div>
                </div>
                
                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p class="stat-label">Workout Time</p>
                            <h3 class="stat-value">45<span style="font-size: 1rem; color: var(--text-muted); font-weight: 500;">min</span></h3>
                            <p style="color: var(--text-muted); font-size: 0.85rem;">Today's session</p>
                        </div>
                        <i data-lucide="timer" style="color: var(--accent-blue);"></i>
                    </div>
                </div>

                <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p class="stat-label">Current Streak</p>
                            <h3 class="stat-value">12<span style="font-size: 1rem; color: var(--text-muted); font-weight: 500;">days</span></h3>
                            <p style="color: #fca5a5; font-size: 0.85rem;">Don't break it!</p>
                        </div>
                        <i data-lucide="calendar-check" style="color: var(--primary);"></i>
                    </div>
                </div>

                 <div class="card">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                        <div>
                            <p class="stat-label">Avg Heart Rate</p>
                            <h3 class="stat-value">128<span style="font-size: 1rem; color: var(--text-muted); font-weight: 500;">bpm</span></h3>
                        </div>
                        <i data-lucide="activity" style="color: #f43f5e;"></i>
                    </div>
                </div>
            </div>

            <!-- Content Split -->
            <div class="grid-2">
                <!-- Recent Activity -->
                <div class="card" style="grid-column: span 1;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <h3>Today's Plan</h3>
                        <button class="btn-ghost">View Full</button>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; align-items: center; padding: 1rem; background: rgba(255,255,255,0.03); border-radius: 12px; margin-bottom: 1rem;">
                        <div style="width: 50px; height: 50px; background: rgba(59, 130, 246, 0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                            <i data-lucide="dumbbell" style="color: var(--accent-blue);"></i>
                        </div>
                        <div style="flex: 1;">
                            <h4 style="margin-bottom: 0.25rem;">Upper Body Power</h4>
                            <p style="font-size: 0.85rem; color: var(--text-muted);">45 mins • Intermediate • Strength</p>
                        </div>
                        <button class="btn" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Start</button>
                    </div>

                    <div style="display: flex; gap: 1rem; align-items: center; padding: 1rem; background: rgba(255,255,255,0.03); border-radius: 12px;">
                        <div style="width: 50px; height: 50px; background: rgba(249, 115, 22, 0.2); border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                            <i data-lucide="footprints" style="color: var(--accent-orange);"></i>
                        </div>
                        <div style="flex: 1;">
                            <h4 style="margin-bottom: 0.25rem;">Cool Down Walk</h4>
                            <p style="font-size: 0.85rem; color: var(--text-muted);">15 mins • Light • Cardio</p>
                        </div>
                        <button class="btn-ghost" style="padding: 0.5rem 1rem; font-size: 0.9rem;">Details</button>
                    </div>
                </div>

                <!-- Graphic/placeholder for chart -->
                <div class="card" style="grid-column: span 1;">
                     <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                        <h3>Activity Zones</h3>
                    </div>
                    <!-- CSS Shim for a chart -->
                    <div style="height: 200px; display: flex; align-items: flex-end; gap: 0.5rem; padding-bottom: 1rem; border-bottom: 1px solid #333;">
                        <div style="flex:1; background: #333; height: 40%; border-radius: 4px;"></div>
                        <div style="flex:1; background: #333; height: 60%; border-radius: 4px;"></div>
                        <div style="flex:1; background: var(--primary-dim); height: 85%; border-radius: 4px;"></div>
                        <div style="flex:1; background: var(--primary); height: 55%; border-radius: 4px; box-shadow: 0 0 10px var(--primary);"></div>
                        <div style="flex:1; background: #333; height: 30%; border-radius: 4px;"></div>
                        <div style="flex:1; background: #333; height: 45%; border-radius: 4px;"></div>
                         <div style="flex:1; background: #333; height: 70%; border-radius: 4px;"></div>
                    </div>
                     <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; color: var(--text-muted); font-size: 0.8rem;">
                        <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}
