export default function Progress() {
    return `
        <div class="animate-enter">
            <h2 style="margin-bottom: 1.5rem;">Your Progress</h2>
            
            <div class="grid-2">
                <!-- Weight Chart -->
                <div class="card" style="grid-column: span 2;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                        <h3>Weight History</h3>
                        <div style="background: rgba(255,255,255,0.1); padding: 0.25rem 0.5rem; border-radius: 8px; font-size: 0.8rem;">
                            Last 30 Days
                        </div>
                    </div>
                    
                    <!-- CSS/SVG Chart -->
                    <div style="height: 250px; position: relative; border-bottom: 1px solid #333; display: flex; align-items: flex-end; justify-content: space-between; padding: 0 1rem 1rem 1rem;">
                        <!-- Grid Lines -->
                        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; display: flex; flex-direction: column; justify-content: space-between; pointer-events: none;">
                            <div style="border-top: 1px dashed #333; height: 1px; width: 100%;"></div>
                            <div style="border-top: 1px dashed #333; height: 1px; width: 100%;"></div>
                            <div style="border-top: 1px dashed #333; height: 1px; width: 100%;"></div>
                            <div style="border-top: 1px dashed #333; height: 1px; width: 100%;"></div>
                        </div>

                        <!-- Data Points (Simulated with Bars for pure CSS/HTML simplicity) -->
                         <div style="width: 8px; background: var(--primary-dim); height: 60%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary-dim); height: 58%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary-dim); height: 62%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary-dim); height: 55%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary-dim); height: 53%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary-dim); height: 50%; border-radius: 4px;"></div>
                         <div style="width: 8px; background: var(--primary); height: 48%; border-radius: 4px; box-shadow: 0 0 10px var(--primary);"></div>
                    </div>
                     <div style="display: flex; justify-content: space-between; margin-top: 0.5rem; color: var(--text-muted); font-size: 0.8rem;">
                        <span>Nov 1</span><span>Nov 5</span><span>Nov 10</span><span>Nov 15</span><span>Nov 20</span><span>Nov 25</span><span>Today</span>
                    </div>
                </div>

                <!-- Personal Records -->
                <div class="card">
                     <h3 style="margin-bottom: 1rem;">Personal Records</h3>
                     <div style="display: flex; flex-direction: column; gap: 1rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #27272a; padding-bottom: 0.5rem;">
                            <span>Bench Press</span>
                            <span style="color: var(--primary); font-weight: 700;">225 lbs</span>
                        </div>
                         <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #27272a; padding-bottom: 0.5rem;">
                            <span>Squat</span>
                            <span style="color: var(--primary); font-weight: 700;">315 lbs</span>
                        </div>
                         <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #27272a; padding-bottom: 0.5rem;">
                            <span>Deadlift</span>
                            <span style="color: var(--primary); font-weight: 700;">405 lbs</span>
                        </div>
                         <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span>5k Run</span>
                            <span style="color: var(--primary); font-weight: 700;">22:30</span>
                        </div>
                     </div>
                </div>

                <!-- Consistency Heatmap -->
                <div class="card">
                    <h3 style="margin-bottom: 1rem;">Consistency</h3>
                    <div style="display: flex; flex-wrap: wrap; gap: 4px;">
                        ${Array(28).fill(0).map((_, i) => {
        const opacity = Math.random() > 0.3 ? (Math.random() * 0.8 + 0.2).toFixed(2) : 0.1;
        const color = Math.random() > 0.5 ? 'var(--primary)' : '#3f3f46';
        return `<div style="width: 30px; height: 30px; background: ${color}; opacity: ${opacity}; border-radius: 4px;"></div>`
    }).join('')}
                    </div>
                </div>
            </div>
        </div>
    `;
}
